namespace PaymentContext.Shared.Commands
{
    public interface ICommandResult
    {
    }
}